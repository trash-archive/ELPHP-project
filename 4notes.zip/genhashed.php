<?php
// Change the string below to the password you want to use
echo password_hash('admin123', PASSWORD_DEFAULT);
